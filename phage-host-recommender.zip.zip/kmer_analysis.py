import sys
from Bio import SeqIO
from collections import Counter
import csv

# ----------------------------
# Check command-line arguments
# ----------------------------
if len(sys.argv) != 4:
    print("Usage: python kmer_analysis.py <fasta_file> <k> <output_csv>")
    sys.exit(1)

fasta_file = sys.argv[1]
k = int(sys.argv[2])
output_file = sys.argv[3]

# ----------------------------
# Read FASTA (handles MULTIPLE records)
# ----------------------------
sequence = ""

for record in SeqIO.parse(fasta_file, "fasta"):
    sequence += str(record.seq).upper()

# ----------------------------
# Generate k-mers
# ----------------------------
kmer_counts = Counter()

for i in range(len(sequence) - k + 1):
    kmer = sequence[i:i+k]
    if "N" not in kmer:   # ignore ambiguous bases
        kmer_counts[kmer] += 1

# ----------------------------
# Write results to CSV
# ----------------------------
with open(output_file, "w", newline="") as csvfile:
    writer = csv.writer(csvfile)
    writer.writerow(["kmer", "count"])
    for kmer, count in kmer_counts.items():
        writer.writerow([kmer, count])

print("K-mer analysis completed")
