import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity
import matplotlib.pyplot as plt

print("\n=== Phage–Host Compatibility Analysis (k = 5) ===\n")

# --------------------------------------------------
# 1. Load datasets
# --------------------------------------------------
bacteria_df = pd.read_csv("final_dataset/bacteria_k5_wide.csv")
phage_df = pd.read_csv("final_dataset/phage_k5_wide.csv")

# Extract names
bacteria_names = bacteria_df["genome_name"]
phage_names = phage_df["genome_name"]

# --------------------------------------------------
# 2. Keep ONLY numeric k-mer columns
# --------------------------------------------------
X_bac = bacteria_df.select_dtypes(include=["number"])
X_phage = phage_df.select_dtypes(include=["number"])

# --------------------------------------------------
# 3. Align on common k-mers
# --------------------------------------------------
common_kmers = X_bac.columns.intersection(X_phage.columns)

X_bac = X_bac[common_kmers]
X_phage = X_phage[common_kmers]

print(f"Number of common k-mers used: {len(common_kmers)}\n")

# --------------------------------------------------
# 4. Compute cosine similarity
# --------------------------------------------------
similarity = cosine_similarity(X_bac, X_phage)

similarity_df = pd.DataFrame(
    similarity,
    index=bacteria_names,
    columns=phage_names
)

# --------------------------------------------------
# 5. Print best phage per bacterium
# --------------------------------------------------
print("Best phage candidates based on genomic similarity:\n")

for bacterium in similarity_df.index:
    best_phage = similarity_df.loc[bacterium].idxmax()
    best_score = similarity_df.loc[bacterium].max()

    print(f"- {bacterium} → {best_phage} (similarity = {best_score:.3f})")

# --------------------------------------------------
# 6. Heatmap visualization
# --------------------------------------------------
plt.figure(figsize=(10, 6))
plt.imshow(similarity_df.values, aspect="auto")
plt.colorbar(label="Cosine Similarity")

plt.xticks(range(len(phage_names)), phage_names, rotation=90)
plt.yticks(range(len(bacteria_names)), bacteria_names)

plt.title("Bacteria–Phage Genomic Similarity Heatmap (k = 5)")
plt.xlabel("Phages")
plt.ylabel("Bacteria")

plt.tight_layout()
plt.show()

# --------------------------------------------------
# 7. Interpretation
# --------------------------------------------------
print("\nInterpretation:")
print("Higher cosine similarity indicates closer genomic composition")
print("between bacterial and phage genomes based on k-mer profiles.")
print("These are computational predictions and require")
print("experimental validation.\n")
