import pandas as pd

files = [
    "final_dataset/bacteria_k4.csv",
    "final_dataset/bacteria_k5.csv",
    "final_dataset/bacteria_k6.csv",
    "final_dataset/phage_k4.csv",
    "final_dataset/phage_k5.csv",
    "final_dataset/phage_k6.csv",
]

for f in files:
    df = pd.read_csv(f)
    print("\nFILE:", f)
    print("Shape (rows, columns):", df.shape)
    print("Missing values:", df.isnull().sum().sum())
    print("Unique types:", df["type"].unique())
