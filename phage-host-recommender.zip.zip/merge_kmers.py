import pandas as pd
import glob
import os

def merge_kmer_folder(input_folder, output_file, label):
    files = glob.glob(os.path.join(input_folder, "*.csv"))
    dfs = []

    for f in files:
        df = pd.read_csv(f)
        df["genome_name"] = os.path.basename(f).replace(".csv", "")
        df["type"] = label
        dfs.append(df)

    merged = pd.concat(dfs, ignore_index=True)
    merged.to_csv(output_file, index=False)
    print(f"Saved: {output_file}")

# BACTERIA
merge_kmer_folder("final_dataset/bacteria/k4", "final_dataset/bacteria_k4.csv", "bacteria")
merge_kmer_folder("final_dataset/bacteria/k5", "final_dataset/bacteria_k5.csv", "bacteria")
merge_kmer_folder("final_dataset/bacteria/k6", "final_dataset/bacteria_k6.csv", "bacteria")

# PHAGE
merge_kmer_folder("final_dataset/phage/k4", "final_dataset/phage_k4.csv", "phage")
merge_kmer_folder("final_dataset/phage/k5", "final_dataset/phage_k5.csv", "phage")
merge_kmer_folder("final_dataset/phage/k6", "final_dataset/phage_k6.csv", "phage")
