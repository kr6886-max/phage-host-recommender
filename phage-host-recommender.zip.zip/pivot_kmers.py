import pandas as pd

def pivot_kmer(input_csv, output_csv):
    df = pd.read_csv(input_csv)

    # Pivot to genome-level matrix
    pivot = df.pivot_table(
        index="genome_name",
        columns="kmer",
        values="count",
        fill_value=0
    )

    # Add label back
    labels = df[["genome_name", "type"]].drop_duplicates().set_index("genome_name")
    pivot["type"] = labels["type"]

    pivot.to_csv(output_csv)
    print(f"Saved: {output_csv}")

# Run for k=5 and k=6
pivot_kmer("final_dataset/bacteria_k5.csv", "final_dataset/bacteria_k5_wide.csv")
pivot_kmer("final_dataset/phage_k5.csv", "final_dataset/phage_k5_wide.csv")

pivot_kmer("final_dataset/bacteria_k6.csv", "final_dataset/bacteria_k6_wide.csv")
pivot_kmer("final_dataset/phage_k6.csv", "final_dataset/phage_k6_wide.csv")
